/**
 * 
 */
/**
 * 
 */
module Fractal {
	requires java.desktop;
}