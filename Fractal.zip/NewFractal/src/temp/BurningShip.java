package temp;

import java.awt.geom.Rectangle2D;

public class BurningShip extends FractalGenerator {
    @Override
    public void getInitialRange(Rectangle2D.Double range) {
        range.x = -2;
        range.y = -2.5;
        range.width = 4;
        range.height = 4;
    }

    @Override
    public int numIterations(double x, double y) {
        double real = x;
        double imag = y;
        int iterations = 0;
        int maxIterations = 2000;

        while (iterations < maxIterations) {
            double realTemp = real * real - imag * imag + x;
            imag = Math.abs(2 * real * imag) + y;
            real = Math.abs(realTemp);

            if (real * real + imag * imag > 4) {
                return iterations;
            }
            iterations++;
        }
        return -1;
    }

    @Override
    public String toString() {
        return "Burning Ship";
    }
}

