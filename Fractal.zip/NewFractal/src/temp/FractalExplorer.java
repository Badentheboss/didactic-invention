package temp;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.io.*;
import javax.imageio.ImageIO;

public class FractalExplorer {
    private int size;
    private Display display;
    private FractalGenerator fractal;
    private JComboBox<FractalGenerator> fractalChooser;
    private JButton saveButton;

    public FractalExplorer(int size) {
        this.size = size;
        fractal = new Mandelbrot();
        display = new Display(size, size);
    }

    public void createAndShowGUI() {
        JFrame frame = new JFrame("Fractal Explorer");
        frame.setLayout(new BorderLayout());

        JPanel panel = new JPanel();
        fractalChooser = new JComboBox<>();
        fractalChooser.addItem(new Mandelbrot());
        fractalChooser.addItem(new Tricorn());
        fractalChooser.addItem(new BurningShip());
        fractalChooser.addActionListener(e -> switchFractal());
        panel.add(new JLabel("Fractal: "));
        panel.add(fractalChooser);
        frame.add(panel, BorderLayout.NORTH);

        frame.add(display, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel();
        JButton resetButton = new JButton("Reset");
        resetButton.addActionListener(e -> resetFractal());
        bottomPanel.add(resetButton);

        saveButton = new JButton("Save Image");
        saveButton.addActionListener(e -> saveImage());
        bottomPanel.add(saveButton);

        frame.add(bottomPanel, BorderLayout.SOUTH);

        // Add mouse listener for zooming
        display.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (SwingUtilities.isLeftMouseButton(e)) {
                    zoom(e.getX(), e.getY(), 0.5);
                } else if (SwingUtilities.isRightMouseButton(e)) {
                    zoom(e.getX(), e.getY(), 2.0);
                }
            }
        });

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
        drawFractal();
    }

    private void switchFractal() {
        fractal = (FractalGenerator) fractalChooser.getSelectedItem();
        resetFractal();
    }

    private void resetFractal() {
        fractal.getInitialRange(display.getRange());
        drawFractal();
    }

    private void drawFractal() {
        for (int x = 0; x < size; x++) {
            for (int y = 0; y < size; y++) {
                double real = fractal.getCoord(display.getRange().x, display.getRange().x + display.getRange().width, size, x);
                double imag = fractal.getCoord(display.getRange().y, display.getRange().y + display.getRange().height, size, y);
                int iter = fractal.numIterations(real, imag);
                int color = iter == -1 ? 0 : Color.HSBtoRGB((float) iter / 200, 1, 1);
                display.drawPixel(x, y, color);
            }
        }
        display.repaint();
    }

    private void zoom(int x, int y, double scale) {
        double xCoord = fractal.getCoord(display.getRange().x, display.getRange().x + display.getRange().width, size, x);
        double yCoord = fractal.getCoord(display.getRange().y, display.getRange().y + display.getRange().height, size, y);

        display.getRange().x = xCoord - (display.getRange().width * scale) / 2;
        display.getRange().y = yCoord - (display.getRange().height * scale) / 2;
        display.getRange().width *= scale;
        display.getRange().height *= scale;

        drawFractal();
    }

    private void saveImage() {
        JFileChooser chooser = new JFileChooser();
        FileNameExtensionFilter filter = new FileNameExtensionFilter("PNG Images", "png");
        chooser.setFileFilter(filter);
        chooser.setAcceptAllFileFilterUsed(false);

        if (chooser.showSaveDialog(display) == JFileChooser.APPROVE_OPTION) {
            File file = chooser.getSelectedFile();
            try {
                ImageIO.write(display.getBufferedImage(), "png", file);
            } catch (IOException e) {
                JOptionPane.showMessageDialog(display, "Error saving image: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public static void main(String[] args) {
        FractalExplorer explorer = new FractalExplorer(600);
        explorer.createAndShowGUI();
    }
}
