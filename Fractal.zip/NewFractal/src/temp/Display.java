package temp;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.awt.geom.Rectangle2D;

public class Display extends JComponent {
    private BufferedImage image;
    private Rectangle2D.Double range;

    public Display(int width, int height) {
        image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        this.setPreferredSize(new Dimension(width, height));
        range = new Rectangle2D.Double(-2, -2, 4, 4); // Default fractal range
    }

    public void clearImage() {
        for (int x = 0; x < image.getWidth(); x++) {
            for (int y = 0; y < image.getHeight(); y++) {
                image.setRGB(x, y, 0);
            }
        }
        repaint();
    }

    public void drawPixel(int x, int y, int rgbColor) {
        if (x >= 0 && x < image.getWidth() && y >= 0 && y < image.getHeight()) {
            image.setRGB(x, y, rgbColor);
        }
    }

    public BufferedImage getBufferedImage() {
        return image; // Allows saving the image
    }

    public Rectangle2D.Double getRange() {
        return range; 
    }

  

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(image, 0, 0, image.getWidth(), image.getHeight(), null);
    }
}


