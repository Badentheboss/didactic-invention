package temp;

import java.awt.geom.Rectangle2D;

public abstract class FractalGenerator {
    public abstract void getInitialRange(Rectangle2D.Double range);
    
    public abstract int numIterations(double x, double y);
    
    public static double getCoord(double rangeMin, double rangeMax, int size, int coord) {
        return rangeMin + (rangeMax - rangeMin) * coord / (size - 1);
    }


}
