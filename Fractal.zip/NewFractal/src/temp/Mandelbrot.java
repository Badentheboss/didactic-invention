package temp;

import java.awt.geom.Rectangle2D;

public class Mandelbrot extends FractalGenerator {
    private static final int MAX_ITERATIONS = 2000;

    @Override
    public void getInitialRange(Rectangle2D.Double range) {
        range.x = -2;
        range.y = -1.5;
        range.width = 3;
        range.height = 3;
    }

    @Override
    public int numIterations(double x, double y) {
        double real = x;
        double imaginary = y;
        int iteration = 0;

        while (iteration < MAX_ITERATIONS) {
            double realSquared = real * real - imaginary * imaginary + x;
            double imaginarySquared = 2 * real * imaginary + y;

            real = realSquared;
            imaginary = imaginarySquared;

            if (real * real + imaginary * imaginary > 4) {
                return iteration;
            }
            iteration++;
        }
        return -1;
    }
}

