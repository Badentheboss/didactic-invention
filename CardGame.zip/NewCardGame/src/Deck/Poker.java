package Deck;

import java.util.ArrayList;
import java.util.Arrays;

public class Poker {

    public static String pokerHand(Hand myHand) {
       
        ArrayList<Card> cards = new ArrayList<>(Arrays.asList(myHand.getContents()));
        
        int[] valuecounter = new int[13]; 
        int[] suitcounter = new int[4];   
        
        for (Card card : cards) {
            valuecounter[card.getValue() - 2]++;  
            suitcounter[SuitIndex(card.getSuit())]++;
        }

        boolean flush = Flush(suitcounter);
        boolean straight = Straight(valuecounter);
        int pairs = Pairs(valuecounter);
        int triples = Triples(valuecounter);
        int quads = Quads(valuecounter);
        
        if (flush && straight && Royal(valuecounter)) return "Royal Flush";
        if (flush && straight) return "Straight Flush";
        if (quads == 1) return "Four of a Kind";
        if (triples == 1 && pairs == 1) return "Full House";
        if (flush) return "Flush";
        if (straight) return "Straight";
        if (triples == 1) return "Three of a Kind";
        if (pairs == 2) return "Two Pair";
        if (pairs == 1) return "Pair";
        
        return "High Card";
    }

    private static boolean Flush(int[] suitCounts) {
        for (int count : suitCounts) {
            if (count == 5) return true;  
        }
        return false;
    }

    private static boolean Straight(int[] valuecounter) {
        for (int i = 0; i <= 8; i++) {  
            if (valuecounter[i] == 1 && valuecounter[i + 1] == 1 && valuecounter[i + 2] == 1 &&
            		valuecounter[i + 3] == 1 && valuecounter[i + 4] == 1) {
                return true;
            }
        }
        return (valuecounter[9] == 1 && valuecounter[10] == 1 && valuecounter[11] == 1 && 
        		valuecounter[12] == 1 && valuecounter[0] == 1);
    }

    private static boolean Royal(int[] valuecounter) {
        return (valuecounter[12] == 1 && valuecounter[11] == 1 && valuecounter[10] == 1 && 
        		valuecounter[9] == 1 && valuecounter[8] == 1);
    }

    private static int SuitIndex(String suit) {
        String[] suits = { "Clubs", "Diamonds", "Hearts", "Spades" };
        
        for (int i = 0; i < suits.length; i++) {
            if (suits[i].equals(suit)) {
                return i;
            }
        }
        return -1;
    }

    private static int Pairs(int[] valuecounter) {
        int pairs = 0;
        for (int valuecounts : valuecounter) {
            if (valuecounts == 2) {
                pairs++;
            }
        }
        return pairs;
    }

    private static int Triples(int[] valuecounter) {
        for (int valuecounts : valuecounter) {
            if (valuecounts == 3) {
                return 1;
            }
        }
        return 0;
    }

    private static int Quads(int[] valuecounter) {
        for (int valuecounts : valuecounter) {
            if (valuecounts == 4) {
                return 1;
            }
        }
        return 0;
    }
    public static double pokerStats(String handType) {
        int trials = 100000; 
        int count = 0;

        for (int i = 0; i < trials; i++) {
            Deck deck = new DeckImpl();  
            deck.shuffle();  

            Hand hand = deck.deal(5);  

          
            if (pokerHand(hand).equals(handType)) {
                count++; 
            }
        }

        return (double) count / trials;
    }
    public static void pokerStatistics() {
        System.out.printf("High Card      : %.4f%%%n", 100 * Poker.pokerStats("High Card"));
        System.out.printf("Pair           : %.4f%%%n", 100 * Poker.pokerStats("Pair"));
        System.out.printf("Two Pair       : %.4f%%%n", 100 * Poker.pokerStats("Two Pair"));
        System.out.printf("Three of a Kind: %.4f%%%n", 100 * Poker.pokerStats("Three of a Kind"));
        System.out.printf("Straight       : %.4f%%%n", 100 * Poker.pokerStats("Straight"));
        System.out.printf("Flush          : %.4f%%%n", 100 * Poker.pokerStats("Flush"));
        System.out.printf("Full House     : %.4f%%%n", 100 * Poker.pokerStats("Full House"));
        System.out.printf("Four of a Kind : %.4f%%%n", 100 * Poker.pokerStats("Four of a Kind"));
        System.out.printf("Straight Flush : %.4f%%%n", 100 * Poker.pokerStats("Straight Flush"));
        System.out.printf("Royal Flush    : %.4f%%%n", 100 * Poker.pokerStats("Royal Flush"));
    }
}
