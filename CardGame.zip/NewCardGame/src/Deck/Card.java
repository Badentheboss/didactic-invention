package Deck;

public interface Card {
    public int getValue(); 
    public String getSuit(); 
    public boolean matchValue(Card otherCard); 
    public boolean matchSuit(Card otherCard); 
}
