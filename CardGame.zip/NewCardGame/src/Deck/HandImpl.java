package Deck;
import java.util.ArrayList;

public class HandImpl implements Hand {
    public ArrayList<Card> cards; 
    public HandImpl(ArrayList<Card> c) {
        cards = c; 
    }
    public void show() {
        for (int i = 0; i < cards.size(); i++) {
            System.out.println(cards.get(i));
        }
    }
    public Card[] getContents() {
        Card[] cardArray = new Card[cards.size()];
        for (int i = 0; i < cards.size(); i++) {
            cardArray[i] = (Card) cards.get(i);
        }
        return cardArray;
    }
}