package Deck;

public interface Hand {
    public void show();   
    public Card[] getContents(); 
}