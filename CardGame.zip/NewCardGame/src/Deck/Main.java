package Deck;

public class Main {
    public static void main(String[] args) {
//        DeckImpl deck = new DeckImpl();
//        System.out.println("Shuffled Deck:");
//        deck.shuffle();
//        for (int i = 0; i < deck.cardsList.size(); i++) {
//            Card card = (Card) deck.cardsList.get(i); // Casting due to raw types
//            System.out.println(card);
//        }
    	Poker trial = new Poker();
    	trial.pokerStatistics();
    }
}
