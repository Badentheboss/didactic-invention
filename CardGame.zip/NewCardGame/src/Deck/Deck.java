package Deck;

public interface Deck {
    void order();
    void shuffle();
    Hand deal(int handSize);
}