package Deck;

public class CardImpl implements Card {
    public int value;
    public String suit;
    public CardImpl(String s, int v) {
        suit = s;
        value = v;
    }
    public int getValue() {
        return value;
    }
    public String getSuit() {
        return suit;
    }
    public boolean matchValue(Card otherCard) {
        if (this.value == otherCard.getValue()) {
            return true;
        } else {
            return false;
        }
    }
    public boolean matchSuit(Card otherCard) {
        if (this.suit.equals(otherCard.getSuit())) {
            return true;
        } else {
            return false;
        }
    }
    public String toString() {
        String cardName = "";
        if (value == 11) {
            cardName = "Jack";
        } else if (value == 12) {
            cardName = "Queen";
        } else if (value == 13) {
            cardName = "King";
        } else if (value == 14) {
            cardName = "Ace";
        } else {
            cardName = "" + value; 
        }
        return cardName + " of " + suit;
    }
}
