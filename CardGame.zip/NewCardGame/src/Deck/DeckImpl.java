package Deck;

import java.util.ArrayList;
import java.util.Random;

public class DeckImpl implements Deck {
    public ArrayList<Card> cardsList; 
    public  String[] suitsArray = {"Clubs", "Diamonds", "Hearts", "Spades"};
    public DeckImpl() {
        cardsList = new ArrayList<Card>();
        for (int i = 0; i < suitsArray.length; i++) {
            for (int val = 2; val <= 14; val++) {
                CardImpl card = new CardImpl(suitsArray[i], val);
                cardsList.add(card);
            }
        }
    }
    public void order() {
        ArrayList<Card> ordered = new ArrayList<Card>();
        for (int i = 0; i < suitsArray.length; i++) {
            for (int val = 2; val <= 14; val++) {
                for (int k = 0; k < cardsList.size(); k++) {
                    Card card = (Card) cardsList.get(k);
                    if (card.getSuit().equals(suitsArray[i]) && card.getValue() == val) {
                        ordered.add(card);
                        break;
                    }
                }
            }
        }
        cardsList = ordered;
    }
    public void shuffle() {
        Random random = new Random();
        for(int i = 0; i < 999; i++) {
        	int first = random.nextInt(cardsList.size());
        	int second = random.nextInt(cardsList.size());
        	Card temp = cardsList.get(first);
        	cardsList.set(first, cardsList.get(second));
        	cardsList.set(second, temp);
        	
        } 
    }
    public Hand deal(int num) {
        if (num > cardsList.size()) {
            System.out.println("Not enough cards!");
            return null;
        }
        ArrayList<Card> hand = new ArrayList<Card>();
        for (int i = 0; i < num; i++) {
        	Card temp = cardsList.remove(0);
            hand.add(temp);
        }
        return new HandImpl(hand);
    }
}